# 确保已经载入了所有必要的包
library(dplyr)
library(ggplot2)
library(readr)
library(stringr) # 加载stringr包

# 使用file.choose()函数让用户选择文件，不给定固定路径，此处打开iri文件
# 原路径：#iri_filepath <- "C:/Users/12768/Desktop/博一上课程作业/交通大数据分析/ iri.csv"
iri_filepath <- file.choose()

# 读取IRI数据集
iri_data <- read_csv(iri_filepath)

# 筛选出STATE_CODE为6且SHRP_ID以"050"开头的子集
iri_subset <- iri_data %>%
  filter(STATE_CODE == 6, str_starts(SHRP_ID, "050"))

# 转换VISIT_DATE为日期格式
iri_subset$VISIT_DATE <- as.Date(iri_subset$VISIT_DATE, format="%m/%d/%y")

# 计算每个部分的IRI摘要统计数据
iri_summary <- iri_subset %>%
  group_by(SHRP_ID) %>%
  summarise(
    Min_IRI = min(IRI, na.rm = TRUE),
    Max_IRI = max(IRI, na.rm = TRUE),
    Mean_IRI = mean(IRI, na.rm = TRUE)
  ) %>%
  arrange(desc(Mean_IRI))

# 选取平均IRI最高的部分
top_section <- iri_summary[1, ]$SHRP_ID

# 从iri_subset中筛选该部分数据
top_section_data <- iri_subset %>%
  filter(SHRP_ID == top_section)

# 计算该部分每个日期的平均IRI
top_section_avg_iri <- top_section_data %>%
  group_by(VISIT_DATE) %>%
  summarise(Average_IRI = mean(IRI, na.rm = TRUE))

# 生成散点图
ggplot(top_section_avg_iri, aes(x = VISIT_DATE, y = Average_IRI)) +
  geom_point() +
  geom_smooth(method = "loess", se = FALSE) +
  labs(title = paste("SHRP ID:", top_section, "- 平均IRI与时间的散点图"),
       x = "日期",
       y = "IRI平均值") +
  theme_minimal()

# 根据需要保存图形
ggsave("top_section_iri_over_time.png", width = 10, height = 5)


# 载入dplyr包
library(dplyr)

# 使用file.choose()选择文件路径
# 原路径：
# accident_path <- "C:/Users/12768/Desktop/博一上课程作业/交通大数据分析/2023-11-02_data-assignment/data-assignment/CRSS/ACCIDENT.csv"
# person_path <- "C:/Users/12768/Desktop/博一上课程作业/交通大数据分析/2023-11-02_data-assignment/data-assignment/CRSS/PERSON.csv"
# vehicle_path <- "C:/Users/12768/Desktop/博一上课程作业/交通大数据分析/2023-11-02_data-assignment/data-assignment/CRSS/VEHICLE.csv"
accident_path <- file.choose()
person_path <- file.choose()
vehicle_path <- file.choose()

# 读取数据集
accident <- read.csv(accident_path, stringsAsFactors = FALSE)
person <- read.csv(person_path, stringsAsFactors = FALSE)
vehicle <- read.csv(vehicle_path, stringsAsFactors = FALSE)

# 获取accident和person数据集的交集
# 这里假设交集是基于CASENUM列
accident_person <- inner_join(accident, person, by = "CASENUM")

# 按伤害严重程度统计观测总数
injury_severity_count <- accident_person %>%
  group_by(INJ_SEV) %>%
  summarise(Total_Observations = n())

# 输出统计结果
print(injury_severity_count)

# 合并事故数据集与车辆数据集
accident_vehicle <- left_join(accident, vehicle, by = "CASENUM")

# 报告结果的尺寸和右侧数据集中一个变量（假设为MAKE）的缺失值数量
result_dimensions <- dim(accident_vehicle)
missing_values_make <- sum(is.na(accident_vehicle$MAKE))

# 输出合并后的数据集尺寸和MAKE变量的缺失值数量
print(result_dimensions)
print(missing_values_make)

