#画散点图
# 安装并加载所需的包
if (!require(ggplot2)) install.packages("ggplot2")
library(ggplot2)
if (!require(readr)) install.packages("readr")
library(readr)

# 让用户选择文件
iri_filepath <- file.choose()

# 读取文件
iri_data <- read_csv(iri_filepath)

# 删除第二、三、四列
iri_data <- iri_data[,-c(2, 3, 4)]

# 确保数据帧有足够的列
if (ncol(iri_data) >= 2) {
  # 重命名列以方便ggplot使用
  names(iri_data) <- c("STATE_CODE", "IRI")
  
  # 使用列的平均值填充缺失值
  iri_data$STATE_CODE[is.na(iri_data$STATE_CODE)] <- mean(iri_data$STATE_CODE, na.rm = TRUE)
  iri_data$IRI[is.na(iri_data$IRI)] <- mean(iri_data$IRI, na.rm = TRUE)
  
  # 绘制散点图
  ggplot(iri_data, aes(x = STATE_CODE, y = IRI)) +
    geom_point(color = "blue") +
    theme_minimal() +
    labs(title = "STATE_CODE vs IRI 散点图", x = "STATE_CODE", y = "IRI") +
    theme(plot.title = element_text(hjust = 0.5))
} else {
  print("数据帧中没有足够的列来绘制散点图。")
}



#循环
# Create a random numeric vector of length 50
vector <- runif(50)

# Initialize a variable to store the sum
sum <- 0

# Loop through each element of the vector to calculate the sum
for(i in 1:length(vector)) {
  sum <- sum + vector[i]
}

# Calculate the mean by dividing the sum by the length of the vector
mean <- sum / length(vector)

# Print the mean
print(mean)
